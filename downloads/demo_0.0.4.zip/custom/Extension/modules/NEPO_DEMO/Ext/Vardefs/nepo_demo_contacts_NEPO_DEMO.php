<?php
// created: 2013-10-17 16:29:50
$dictionary["NEPO_DEMO"]["fields"]["nepo_demo_contacts"] = array (
  'name' => 'nepo_demo_contacts',
  'type' => 'link',
  'relationship' => 'nepo_demo_contacts',
  'source' => 'non-db',
  'module' => 'Contacts',
  'bean_name' => 'Contact',
  'vname' => 'LBL_NEPO_DEMO_CONTACTS_FROM_CONTACTS_TITLE',
);
