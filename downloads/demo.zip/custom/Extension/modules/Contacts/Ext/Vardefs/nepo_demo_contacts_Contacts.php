<?php
// created: 2013-10-17 16:29:50
$dictionary["Contact"]["fields"]["nepo_demo_contacts"] = array (
  'name' => 'nepo_demo_contacts',
  'type' => 'link',
  'relationship' => 'nepo_demo_contacts',
  'source' => 'non-db',
  'module' => 'NEPO_DEMO',
  'bean_name' => false,
  'vname' => 'LBL_NEPO_DEMO_CONTACTS_FROM_NEPO_DEMO_TITLE',
);
