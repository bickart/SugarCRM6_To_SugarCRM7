<?php
// created: 2013-10-17 16:29:50
$dictionary["NEPO_DEMO"]["fields"]["nepo_demo_leads"] = array (
  'name' => 'nepo_demo_leads',
  'type' => 'link',
  'relationship' => 'nepo_demo_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'vname' => 'LBL_NEPO_DEMO_LEADS_FROM_LEADS_TITLE',
);
