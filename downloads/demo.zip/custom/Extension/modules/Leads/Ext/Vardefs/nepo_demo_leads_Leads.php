<?php
// created: 2013-10-17 16:29:50
$dictionary["Lead"]["fields"]["nepo_demo_leads"] = array (
  'name' => 'nepo_demo_leads',
  'type' => 'link',
  'relationship' => 'nepo_demo_leads',
  'source' => 'non-db',
  'module' => 'NEPO_DEMO',
  'bean_name' => false,
  'vname' => 'LBL_NEPO_DEMO_LEADS_FROM_NEPO_DEMO_TITLE',
);
