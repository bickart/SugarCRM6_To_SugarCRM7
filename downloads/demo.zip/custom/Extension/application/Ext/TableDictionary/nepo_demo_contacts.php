<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/nepo_demo_contactsMetaData.php');

?>