<?php 
 //WARNING: The contents of this file are auto-generated
$beanList['NEPO_DEMO'] = 'NEPO_DEMO';
$beanFiles['NEPO_DEMO'] = 'modules/NEPO_DEMO/NEPO_DEMO.php';
$moduleList[] = 'NEPO_DEMO';

?>