<?php
/**
 * Copyright 2013 NEPO Systems, LLC
 *
 * User: @bickart
 * Date: 10/18/2013
 * Time: 9:30 AM
 * 
 */

$action_view_map['special'] = 'somethingspecial';
$action_view_map['schema'] = 'schema';